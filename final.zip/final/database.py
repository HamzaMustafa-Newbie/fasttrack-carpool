"""
FastTrack Database Module
Handles all database operations for the carpool system
"""

import os
try:
    import oracledb
except ImportError:
    import cx_Oracle as oracledb
    # For older systems that might have cx_Oracle installed
from datetime import datetime
from typing import List, Dict, Optional, Tuple


ORACLE_CLIENT_INITIALIZED = False


def ensure_oracle_client():
    """
    Ensure Oracle thick client libraries are initialized.
    Required for connecting to Oracle 11g servers using oracledb.
    """
    global ORACLE_CLIENT_INITIALIZED
    if ORACLE_CLIENT_INITIALIZED:
        return

    if hasattr(oracledb, "init_oracle_client"):
        lib_dir = os.environ.get("ORACLE_CLIENT_LIB_DIR")
        if not lib_dir:
            possible_dirs = [
                r"C:\oraclexe\app\oracle\product\11.2.0\server\bin",
                r"C:\oracle\product\11.2.0\dbhome_1\BIN",
                r"C:\app\oracle\product\11.2.0\dbhome_1\BIN",
                "/u01/app/oracle/product/11.2.0/xe/lib",
                "/opt/oracle/instantclient_11_2",
            ]
            for path in possible_dirs:
                if os.path.isdir(path):
                    lib_dir = path
                    break

        if lib_dir:
            try:
                oracledb.init_oracle_client(lib_dir=lib_dir)
                ORACLE_CLIENT_INITIALIZED = True
                return
            except oracledb.ProgrammingError as exc:
                print(f"Warning: Failed to initialize Oracle client at {lib_dir}: {exc}")

        print(
            "Oracle client libraries not found. "
            "Set ORACLE_CLIENT_LIB_DIR to your Oracle 11g client 'bin' directory."
        )
    ORACLE_CLIENT_INITIALIZED = True

class Database:
    def __init__(self):
        self.connection = None
        self.cursor = None
        self._connected = False
        self._column_cache = {}
        
    def connect(self):
        """Establish connection to Oracle database"""
        try:
            ensure_oracle_client()
            dsn = oracledb.makedsn(
                host='oracle-db',
                port=1521,
                service_name='XEPDB1'
            )
            self.connection = oracledb.connect(
                user='hr',
                password='fast',
                dsn=dsn
            )
            self.cursor = self.connection.cursor()
            self._connected = True
            print("Connected to Oracle database successfully!")
            return True
        except oracledb.Error as e:
            print(f"Error connecting to database: {e}")
            return False
    
    def disconnect(self):
        """Close database connection"""
        if self.cursor:
            self.cursor.close()
        if self.connection:
            self.connection.close()
        self._connected = False
        print("Disconnected from database")

    def __enter__(self):
        if not self._connected:
            self.connect()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.disconnect()
    
    def execute_query(self, query: str, params: tuple = None) -> List:
        """Execute SELECT query and return results.

        This helper now makes sure we have an active database connection
        before trying to run the query, which avoids silent failures if
        the connection was never created or was dropped.
        """
        # Lazily ensure connection is available
        if not self._connected and not self.connect():
            print("Query execution error: database connection is not available.")
            return []

        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            return self.cursor.fetchall()
        except oracledb.Error as e:
            print(f"Query execution error: {e}")
            return []
    
    def execute_update(self, query: str, params: tuple = None) -> bool:
        """Execute INSERT, UPDATE, DELETE query.

        Like ``execute_query``, this now ensures a live connection first so
        callers don't need to remember to connect explicitly.
        """
        # Lazily ensure connection is available
        if not self._connected and not self.connect():
            print("Update execution error: database connection is not available.")
            return False

        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            self.connection.commit()
            return True
        except oracledb.Error as e:
            self.connection.rollback()
            print(f"Update execution error: {e}")
            return False
    
    def _column_exists(self, table_name: str, column_name: str) -> bool:
        """Check if a column exists in the current schema (cached)."""
        key = (table_name.upper(), column_name.upper())
        if key in self._column_cache:
            return self._column_cache[key]
        if not self._connected and not self.connect():
            self._column_cache[key] = False
            return False

        query = """
            SELECT COUNT(*)
            FROM user_tab_columns
            WHERE table_name = :1 AND column_name = :2
        """
        result = self.execute_query(query, key)
        exists = bool(result and result[0][0])
        self._column_cache[key] = exists
        return exists
    
    # Student Operations
    def register_student(
        self,
        name: str,
        email: str,
        password: str,
        department: str,
        semester: int,
        vehicle_available: str,
        vehicle_details: str = None,
        phone: str = None,
        is_admin: str = 'N',
        approval_status: str = 'PENDING',
    ) -> bool:
        """Register a new student"""
        query = """
            INSERT INTO students (
                name,
                email,
                password,
                department,
                semester,
                vehicle_available,
                vehicle_details,
                phone,
                is_admin,
                approval_status
            )
            VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10)
        """
        return self.execute_update(
            query,
            (
                name,
                email,
                password,
                department,
                semester,
                vehicle_available,
                vehicle_details,
                phone,
                is_admin,
                approval_status,
            ),
        )

    def register_vehicle(
        self,
        student_id: int,
        vehicle_type: str,
        vehicle_make: str = None,
        vehicle_model: str = None,
        vehicle_year: int = None,
        license_plate: str = None,
        registration_number: str = None,
        registration_status: str = 'PENDING',
    ) -> bool:
        """Register a vehicle for a student"""
        query = """
            INSERT INTO vehicle_registrations (
                student_id,
                vehicle_type,
                vehicle_make,
                vehicle_model,
                vehicle_year,
                license_plate,
                registration_number,
                registration_status
            )
            VALUES (:1, :2, :3, :4, :5, :6, :7, :8)
        """
        return self.execute_update(
            query,
            (
                student_id,
                vehicle_type,
                vehicle_make,
                vehicle_model,
                vehicle_year,
                license_plate,
                registration_number,
                registration_status,
            ),
        )
    
    def authenticate_student(self, email: str, password: str) -> Optional[Dict]:
        """Authenticate student login"""
        query = """
            SELECT student_id, name, email, department, semester, vehicle_available, 
                   vehicle_details, phone, is_admin, approval_status
            FROM students
            WHERE email = :1 AND password = :2
        """
        result = self.execute_query(query, (email, password))
        if result:
            row = result[0]
            return {
                'student_id': row[0],
                'name': row[1],
                'email': row[2],
                'department': row[3],
                'semester': row[4],
                'vehicle_available': row[5],
                'vehicle_details': row[6],
                'phone': row[7],
                'is_admin': row[8],
                'approval_status': row[9],
            }
        return None
    
    def get_student_by_id(self, student_id: int) -> Optional[Dict]:
        """Get student details by ID"""
        query = """
            SELECT student_id, name, email, department, semester, vehicle_available, 
                   vehicle_details, phone, is_admin, approval_status
            FROM students
            WHERE student_id = :1
        """
        result = self.execute_query(query, (student_id,))
        if result:
            row = result[0]
            return {
                'student_id': row[0],
                'name': row[1],
                'email': row[2],
                'department': row[3],
                'semester': row[4],
                'vehicle_available': row[5],
                'vehicle_details': row[6],
                'phone': row[7],
                'is_admin': row[8],
                'approval_status': row[9]
            }
        return None
    
    def get_student_by_email(self, email: str) -> Optional[Dict]:
        """Get student details by email"""
        query = """
            SELECT student_id, name, email, department, semester, vehicle_available,
                   vehicle_details, phone, is_admin, approval_status
            FROM students
            WHERE LOWER(email) = LOWER(:1)
        """
        result = self.execute_query(query, (email,))
        if result:
            row = result[0]
            return {
                'student_id': row[0],
                'name': row[1],
                'email': row[2],
                'department': row[3],
                'semester': row[4],
                'vehicle_available': row[5],
                'vehicle_details': row[6],
                'phone': row[7],
                'is_admin': row[8],
                'approval_status': row[9]
            }
        return None

    def get_pending_students(self) -> List[Dict]:
        """Return students awaiting administrative approval"""
        query = """
            SELECT student_id, name, email, department, semester, vehicle_available,
                   registration_date
            FROM students
            WHERE approval_status = 'PENDING'
            ORDER BY registration_date
        """
        result = self.execute_query(query)
        pending = []
        for row in result:
            pending.append(
                {
                    'student_id': row[0],
                    'name': row[1],
                    'email': row[2],
                    'department': row[3],
                    'semester': row[4],
                    'vehicle_available': row[5],
                    'registration_date': row[6],
                }
            )
        return pending

    def update_student_approval(self, student_id: int, status: str) -> bool:
        """Approve or reject a student registration"""
        if status not in ('APPROVED', 'REJECTED'):
            return False

        params = {"status": status, "student_id": student_id}
        if self._column_exists('students', 'approval_date'):
            query = """
                UPDATE students
                SET approval_status = :status,
                    approval_date = CASE WHEN :status = 'APPROVED' THEN SYSTIMESTAMP ELSE NULL END
                WHERE student_id = :student_id
                  AND is_admin = 'N'
            """
        else:
            query = """
                UPDATE students
                SET approval_status = :status
                WHERE student_id = :student_id
                  AND is_admin = 'N'
            """
        success = self.execute_update(query, params)
        if success:
            notif_status = 'SUCCESS' if status == 'APPROVED' else 'WARNING'
            message = (
                "Your FastTrack registration has been approved. You can now sign in!"
                if status == 'APPROVED'
                else "Your FastTrack registration was rejected. Please contact support for details."
            )
            self.create_notification(student_id, "Registration update", message, notif_status)
        return success
    
    # Notification Operations
    def create_notification(
        self,
        student_id: int,
        title: str,
        notification_message: str,
        notification_type: str = 'INFO',
        commit: bool = True,
    ) -> bool:
        """Create a notification for a student"""
        if not self._connected and not self.connect():
            return False
        try:
            self.cursor.execute(
                """
                INSERT INTO notifications (student_id, title, message, notification_type)
                VALUES (:1, :2, :3, :4)
                """,
                (
                    student_id,
                    (title or '')[:200],
                    (notification_message or '')[:1000],
                    notification_type,
                ),
            )
            if commit:
                self.connection.commit()
            return True
        except oracledb.Error as exc:
            if commit:
                self.connection.rollback()
            print(f"Failed to create notification: {exc}")
            return False
    
    def get_notifications(self, student_id: int, include_read: bool = False, limit: int = 50) -> List[Dict]:
        """Fetch notifications for a student"""
        clause = "" if include_read else "AND is_read = 'N'"
        limit = max(1, min(limit, 200))
        query = f"""
            SELECT notification_id, title, message, notification_type, is_read, created_date
            FROM notifications
            WHERE student_id = :1 {clause}
            ORDER BY created_date DESC
            FETCH FIRST {limit} ROWS ONLY
        """
        result = self.execute_query(query, (student_id,))
        notifications = []
        for row in result:
            notifications.append(
                {
                    'notification_id': row[0],
                    'title': row[1],
                    'message': row[2],
                    'notification_type': row[3],
                    'is_read': row[4],
                    'created_date': row[5],
                }
            )
        return notifications
    
    def mark_notification_read(self, notification_id: int, student_id: int) -> bool:
        """Mark a single notification as read"""
        query = """
            UPDATE notifications
            SET is_read = 'Y'
            WHERE notification_id = :1 AND student_id = :2
        """
        return self.execute_update(query, (notification_id, student_id))
    
    def mark_all_notifications_read(self, student_id: int) -> bool:
        """Mark all notifications for a student as read"""
        query = """
            UPDATE notifications
            SET is_read = 'Y'
            WHERE student_id = :1 AND is_read = 'N'
        """
        return self.execute_update(query, (student_id,))
    
    def _get_admin_ids(self) -> List[int]:
        """Return IDs of admin users"""
        result = self.execute_query("SELECT student_id FROM students WHERE is_admin = 'Y'")
        return [row[0] for row in result] if result else []
    
    # Messaging Operations
    def get_messaging_recipients(self, exclude_student_id: int) -> List[Dict]:
        """Get approved students available for messaging"""
        query = """
            SELECT student_id, name, email
            FROM students
            WHERE approval_status = 'APPROVED'
              AND student_id != :1
            ORDER BY name
        """
        result = self.execute_query(query, (exclude_student_id,))
        recipients = []
        for row in result:
            recipients.append(
                {
                    'student_id': row[0],
                    'name': row[1],
                    'email': row[2],
                }
            )
        return recipients
    
    def send_message(
        self,
        sender_id: int,
        receiver_id: int,
        subject: str,
        message_text: str,
        ride_id: Optional[int] = None,
    ) -> bool:
        """Send a direct message"""
        query = """
            INSERT INTO messages (sender_id, receiver_id, ride_id, subject, message_text)
            VALUES (:1, :2, :3, :4, :5)
        """
        success = self.execute_update(
            query,
            (
                sender_id,
                receiver_id,
                ride_id,
                (subject or '')[:200],
                message_text,
            ),
        )
        if success:
            sender = self.get_student_by_id(sender_id)
            sender_name = sender['name'] if sender else 'FastTrack User'
            preview = (message_text or '')[:120]
            self.create_notification(
                receiver_id,
                f"Message from {sender_name}",
                preview or "You have received a new message.",
                'INFO',
            )
        return success
    
    def get_inbox_messages(self, student_id: int) -> List[Dict]:
        """Fetch inbox messages"""
        query = """
            SELECT m.message_id, m.sender_id, s.name, s.email, m.subject, m.message_text,
                   m.ride_id, m.is_read, m.created_date
            FROM messages m
            JOIN students s ON m.sender_id = s.student_id
            WHERE m.receiver_id = :1
            ORDER BY m.created_date DESC
        """
        result = self.execute_query(query, (student_id,))
        messages = []
        for row in result:
            messages.append(
                {
                    'message_id': row[0],
                    'sender_id': row[1],
                    'sender_name': row[2],
                    'sender_email': row[3],
                    'subject': row[4],
                    'message_text': row[5],
                    'ride_id': row[6],
                    'is_read': row[7],
                    'created_date': row[8],
                }
            )
        return messages
    
    def get_sent_messages(self, student_id: int) -> List[Dict]:
        """Fetch sent messages"""
        query = """
            SELECT m.message_id, m.receiver_id, s.name, s.email, m.subject, m.message_text,
                   m.ride_id, m.created_date
            FROM messages m
            JOIN students s ON m.receiver_id = s.student_id
            WHERE m.sender_id = :1
            ORDER BY m.created_date DESC
        """
        result = self.execute_query(query, (student_id,))
        messages = []
        for row in result:
            messages.append(
                {
                    'message_id': row[0],
                    'receiver_id': row[1],
                    'receiver_name': row[2],
                    'receiver_email': row[3],
                    'subject': row[4],
                    'message_text': row[5],
                    'ride_id': row[6],
                    'created_date': row[7],
                }
            )
        return messages
    
    def mark_message_read(self, message_id: int, student_id: int) -> bool:
        """Mark message as read"""
        query = """
            UPDATE messages
            SET is_read = 'Y'
            WHERE message_id = :1 AND receiver_id = :2
        """
        return self.execute_update(query, (message_id, student_id))
    
    # Complaint Operations
    def file_complaint(
        self,
        complainant_id: int,
        title: str,
        description: str,
        complaint_type: str = 'GENERAL',
        respondent_id: Optional[int] = None,
        ride_id: Optional[int] = None,
    ) -> bool:
        """Create a complaint record"""
        query = """
            INSERT INTO complaints (complainant_id, respondent_id, ride_id, complaint_type, title, description)
            VALUES (:1, :2, :3, :4, :5, :6)
        """
        success = self.execute_update(
            query,
            (complainant_id, respondent_id, ride_id, complaint_type, title[:200], description[:2000]),
        )
        if success:
            self.create_notification(
                complainant_id,
                "Complaint submitted",
                "Your complaint has been submitted and will be reviewed by admin.",
                'INFO',
            )
            if respondent_id:
                self.create_notification(
                    respondent_id,
                    "Complaint filed against you",
                    "A complaint has been filed referencing your account. Admin will review it shortly.",
                    'WARNING',
                )
            for admin_id in self._get_admin_ids():
                self.create_notification(
                    admin_id,
                    "New complaint waiting for review",
                    f"A new complaint titled '{title[:150]}' requires your attention.",
                    'WARNING',
                )
        return success
    
    def get_complaints_for_user(self, student_id: int) -> List[Dict]:
        """Fetch complaints where the user is complainant or respondent"""
        query = """
            SELECT c.complaint_id, c.complainant_id, comp.name, c.respondent_id, resp.name,
                   c.ride_id, c.complaint_type, c.title, c.description, c.status,
                   c.admin_response, c.created_date, c.resolved_date
            FROM complaints c
            LEFT JOIN students comp ON comp.student_id = c.complainant_id
            LEFT JOIN students resp ON resp.student_id = c.respondent_id
            WHERE c.complainant_id = :1 OR c.respondent_id = :1
            ORDER BY c.created_date DESC
        """
        result = self.execute_query(query, (student_id,))
        complaints = []
        for row in result:
            role = 'Complainant' if row[1] == student_id else 'Respondent'
            complaints.append(
                {
                    'complaint_id': row[0],
                    'complainant_id': row[1],
                    'complainant_name': row[2],
                    'respondent_id': row[3],
                    'respondent_name': row[4],
                    'ride_id': row[5],
                    'complaint_type': row[6],
                    'title': row[7],
                    'description': row[8],
                    'status': row[9],
                    'admin_response': row[10],
                    'created_date': row[11],
                    'resolved_date': row[12],
                    'role': role,
                }
            )
        return complaints
    
    def get_all_complaints(self) -> List[Dict]:
        """Fetch all complaints for admin review"""
        query = """
            SELECT c.complaint_id, c.complainant_id, comp.name, c.respondent_id, resp.name,
                   c.ride_id, c.complaint_type, c.title, c.description, c.status,
                   c.admin_response, c.created_date, c.resolved_date
            FROM complaints c
            LEFT JOIN students comp ON comp.student_id = c.complainant_id
            LEFT JOIN students resp ON resp.student_id = c.respondent_id
            ORDER BY c.created_date DESC
        """
        result = self.execute_query(query)
        complaints = []
        for row in result:
            complaints.append(
                {
                    'complaint_id': row[0],
                    'complainant_id': row[1],
                    'complainant_name': row[2],
                    'respondent_id': row[3],
                    'respondent_name': row[4],
                    'ride_id': row[5],
                    'complaint_type': row[6],
                    'title': row[7],
                    'description': row[8],
                    'status': row[9],
                    'admin_response': row[10],
                    'created_date': row[11],
                    'resolved_date': row[12],
                }
            )
        return complaints
    
    def get_complaint_by_id(self, complaint_id: int) -> Optional[Dict]:
        """Fetch a specific complaint"""
        query = """
            SELECT complaint_id, complainant_id, respondent_id, ride_id, complaint_type,
                   title, description, status, admin_response
            FROM complaints
            WHERE complaint_id = :1
        """
        result = self.execute_query(query, (complaint_id,))
        if result:
            row = result[0]
            return {
                'complaint_id': row[0],
                'complainant_id': row[1],
                'respondent_id': row[2],
                'ride_id': row[3],
                'complaint_type': row[4],
                'title': row[5],
                'description': row[6],
                'status': row[7],
                'admin_response': row[8],
            }
        return None
    
    def update_complaint_status(
        self,
        complaint_id: int,
        status: str,
        admin_response: Optional[str],
        admin_id: int,
    ) -> bool:
        """Update complaint status and record admin response"""
        if status not in ('PENDING', 'UNDER_REVIEW', 'RESOLVED', 'DISMISSED'):
            return False
        query = """
            UPDATE complaints
            SET status = :1,
                admin_response = :2,
                resolved_date = CASE WHEN :1 IN ('RESOLVED', 'DISMISSED') THEN SYSTIMESTAMP ELSE NULL END
            WHERE complaint_id = :3
        """
        success = self.execute_update(
            query,
            (
                status,
                (admin_response or '')[:2000] if admin_response else None,
                complaint_id,
            ),
        )
        if success:
            complaint = self.get_complaint_by_id(complaint_id)
            if complaint:
                message = (
                    f"Admin updated your complaint '{complaint['title']}': {status}."
                    if admin_response
                    else f"Your complaint '{complaint['title']}' status changed to {status}."
                )
                self.create_notification(
                    complaint['complainant_id'], "Complaint update", message, 'INFO'
                )
                if complaint.get('respondent_id'):
                    self.create_notification(
                        complaint['respondent_id'],
                        "Complaint status update",
                        f"A complaint referencing you is now marked as {status}.",
                        'INFO',
                    )
            self.create_notification(
                admin_id,
                "Complaint updated",
                f"Complaint #{complaint_id} marked as {status}.",
                'SUCCESS',
            )
        return success
    
    # Ride Operations
    def create_ride(self, driver_id: int, source: str, destination: str,
                   departure_time: datetime, available_seats: int,
                   price_per_seat: float = 0, pickup_point: str = None,
                   route_description: str = None) -> bool:
        """Create a new ride"""
        query = """
            INSERT INTO rides (driver_id, source_location, destination_location,
                             departure_time, available_seats, price_per_seat, pickup_point, route_description)
            VALUES (:1, :2, :3, :4, :5, :6, :7, :8)
        """
        return self.execute_update(query, (driver_id, source, destination, departure_time,
                                          available_seats, price_per_seat, pickup_point, route_description))
    
    def search_rides(self, source: str = None, destination: str = None,
                    pickup_point: str = None, departure_date: str = None) -> List[Dict]:
        """Search for available rides"""
        conditions = ["status = 'ACTIVE'"]
        params = []
        param_num = 1
        
        if source:
            conditions.append(f"UPPER(source_location) LIKE UPPER(:{param_num})")
            params.append(f'%{source}%')
            param_num += 1
        if destination:
            conditions.append(f"UPPER(destination_location) LIKE UPPER(:{param_num})")
            params.append(f'%{destination}%')
            param_num += 1
        if pickup_point:
            conditions.append(f"UPPER(pickup_point) LIKE UPPER(:{param_num})")
            params.append(f'%{pickup_point}%')
            param_num += 1
        if departure_date:
            conditions.append(f"TRUNC(departure_time) = TO_DATE(:{param_num}, 'YYYY-MM-DD')")
            params.append(departure_date)
            param_num += 1
        
        query = f"""
            SELECT r.ride_id, r.driver_id, s.name as driver_name, r.source_location, 
                   r.destination_location, r.departure_time, r.available_seats, 
                   r.price_per_seat, r.pickup_point, r.route_description,
                   (
                       SELECT NVL(SUM(b.seats_booked), 0)
                       FROM bookings b
                       WHERE b.ride_id = r.ride_id 
                         AND b.status IN ('CONFIRMED', 'IN_PROGRESS')
                   ) as booked_seats,
                   s.vehicle_details
            FROM rides r
            JOIN students s ON r.driver_id = s.student_id
            WHERE {' AND '.join(conditions)}
            ORDER BY r.departure_time
        """
        
        result = self.execute_query(query, tuple(params) if params else None)
        rides = []
        for row in result:
            rides.append({
                'ride_id': row[0],
                'driver_id': row[1],
                'driver_name': row[2],
                'source': row[3],
                'destination': row[4],
                'departure_time': row[5],
                'available_seats': row[6],
                'price_per_seat': row[7],
                'pickup_point': row[8],
                'route_description': row[9],
                'booked_seats': row[10] if len(row) > 10 and row[10] is not None else 0,
                'vehicle_details': row[11] if len(row) > 11 else None
            })
        return rides
    
    def get_ride_by_id(self, ride_id: int) -> Optional[Dict]:
        """Get ride details by ID"""
        query = """
            SELECT r.ride_id, r.driver_id, s.name as driver_name, r.source_location, 
                   r.destination_location, r.departure_time, r.available_seats, 
                   r.price_per_seat, r.pickup_point, r.route_description, r.status,
                   (
                       SELECT NVL(SUM(b.seats_booked), 0)
                       FROM bookings b 
                       WHERE b.ride_id = r.ride_id 
                         AND b.status IN ('CONFIRMED', 'IN_PROGRESS')
                   ) as booked_seats,
                   s.vehicle_details
            FROM rides r
            JOIN students s ON r.driver_id = s.student_id
            WHERE r.ride_id = :1
        """
        result = self.execute_query(query, (ride_id,))
        if result:
            row = result[0]
            return {
                'ride_id': row[0],
                'driver_id': row[1],
                'driver_name': row[2],
                'source': row[3],
                'destination': row[4],
                'departure_time': row[5],
                'available_seats': row[6],
                'price_per_seat': row[7],
                'pickup_point': row[8],
                'route_description': row[9],
                'status': row[10],
                'booked_seats': row[11] if len(row) > 11 and row[11] is not None else 0,
                'vehicle_details': row[12] if len(row) > 12 else None
            }
        return None
    
    def get_my_rides(self, student_id: int, role: str = 'driver') -> List[Dict]:
        """Get rides posted by a student (as driver)"""
        query = """
            SELECT r.ride_id, r.source_location, r.destination_location, 
                   r.departure_time, r.available_seats, r.price_per_seat, 
                   r.status, r.route_description, r.pickup_point,
                   (
                       SELECT NVL(SUM(b.seats_booked), 0)
                       FROM bookings b
                       WHERE b.ride_id = r.ride_id 
                         AND b.status IN ('CONFIRMED', 'IN_PROGRESS')
                   ) as booked_seats
            FROM rides r
            WHERE r.driver_id = :1
            ORDER BY r.departure_time DESC
        """
        result = self.execute_query(query, (student_id,))
        rides = []
        for row in result:
            rides.append({
                'ride_id': row[0],
                'source': row[1],
                'destination': row[2],
                'departure_time': row[3],
                'available_seats': row[4],
                'price_per_seat': row[5],
                'status': row[6],
                'route_description': row[7],
                'pickup_point': row[8],
                'booked_seats': row[9] if len(row) > 9 and row[9] is not None else 0
            })
        return rides
    
    # Booking Operations
    def create_booking(self, ride_id: int, passenger_id: int, seats: int = 1) -> bool:
        """Create a booking for a ride"""
        # Check if seats are available
        ride = self.get_ride_by_id(ride_id)
        if not ride:
            return False

        if ride['driver_id'] == passenger_id:
            return False
        
        if ride['status'] != 'ACTIVE':
            return False
        
        booked = ride.get('booked_seats', 0) or 0
        if booked + seats > ride['available_seats']:
            return False
        
        query = """
            INSERT INTO bookings (ride_id, passenger_id, seats_booked, payment_status)
            VALUES (:1, :2, :3, 'PENDING')
        """
        success = self.execute_update(query, (ride_id, passenger_id, seats))
        if success:
            self.create_notification(
                passenger_id,
                "Booking confirmed",
                f"You booked {seats} seat(s) for ride {ride['source']} → {ride['destination']}.",
                'SUCCESS',
            )
            self.create_notification(
                ride['driver_id'],
                "New booking received",
                f"A passenger booked {seats} seat(s) for your ride {ride['source']} → {ride['destination']}.",
                'INFO',
            )
        return success
    
    def get_my_bookings(self, student_id: int) -> List[Dict]:
        """Get bookings made by a student (as passenger)"""
        query = """
            SELECT b.booking_id,
                   b.ride_id,
                   r.source_location,
                   r.destination_location, 
                   r.departure_time,
                   r.pickup_point,
                   r.driver_id,
                   s.name as driver_name,
                   b.booking_time, 
                   b.status,
                   b.seats_booked,
                   r.price_per_seat,
                   r.status as ride_status,
                   b.payment_status,
                   (SELECT COUNT(*) FROM payments p WHERE p.booking_id = b.booking_id AND p.payment_status = 'COMPLETED') as payment_count
            FROM bookings b
            JOIN rides r ON b.ride_id = r.ride_id
            JOIN students s ON r.driver_id = s.student_id
            WHERE b.passenger_id = :1
            ORDER BY b.booking_time DESC
        """
        result = self.execute_query(query, (student_id,))
        bookings = []
        for row in result:
            bookings.append({
                'booking_id': row[0],
                'ride_id': row[1],
                'source': row[2],
                'destination': row[3],
                'departure_time': row[4],
                'pickup_point': row[5],
                'driver_id': row[6],
                'driver_name': row[7],
                'booking_time': row[8],
                'status': row[9],
                'seats_booked': row[10],
                'price_per_seat': row[11],
                'ride_status': row[12],
                'payment_status': row[13] if len(row) > 13 else 'PENDING',
                'payment_count': row[14] if len(row) > 14 else 0
            })
        return bookings
    
    def get_passengers_for_ride(self, ride_id: int) -> List[Dict]:
        """Get all passengers for a specific ride"""
        query = """
            SELECT b.booking_id, s.student_id, s.name, s.email, s.phone, 
                   b.booking_time, b.status, b.seats_booked
            FROM bookings b
            JOIN students s ON b.passenger_id = s.student_id
            WHERE b.ride_id = :1 
              AND b.status IN ('CONFIRMED', 'IN_PROGRESS', 'COMPLETED')
            ORDER BY b.booking_time
        """
        result = self.execute_query(query, (ride_id,))
        passengers = []
        for row in result:
            passengers.append({
                'booking_id': row[0],
                'student_id': row[1],
                'name': row[2],
                'email': row[3],
                'phone': row[4],
                'booking_time': row[5],
                'status': row[6],
                'seats_booked': row[7]
            })
        return passengers

    def get_booking_with_ride(self, booking_id: int) -> Optional[Dict]:
        """Get booking details alongside ride status"""
        query = """
            SELECT b.booking_id, b.ride_id, b.passenger_id, b.status,
                   r.status as ride_status, b.seats_booked, b.payment_status,
                   r.driver_id, r.price_per_seat
            FROM bookings b
            JOIN rides r ON b.ride_id = r.ride_id
            WHERE b.booking_id = :1
        """
        result = self.execute_query(query, (booking_id,))
        if not result:
            return None
        row = result[0]
        return {
            'booking_id': row[0],
            'ride_id': row[1],
            'passenger_id': row[2],
            'status': row[3],
            'ride_status': row[4],
            'seats_booked': row[5] if len(row) > 5 else 1,
            'payment_status': row[6] if len(row) > 6 else 'PENDING',
            'driver_id': row[7] if len(row) > 7 else None,
            'price_per_seat': row[8] if len(row) > 8 else 0
        }

    def cancel_booking(self, booking_id: int, passenger_id: int) -> Tuple[bool, str]:
        """Cancel a booking if the ride has not started"""
        booking = self.get_booking_with_ride(booking_id)
        if not booking or booking['passenger_id'] != passenger_id:
            return False, "Booking not found."

        if booking['ride_status'] != 'ACTIVE':
            return False, "You can only cancel before the ride starts."

        if booking['status'] != 'CONFIRMED':
            return False, "Booking cannot be cancelled."

        try:
            self.cursor.execute(
                """
                UPDATE bookings
                SET status = 'CANCELLED'
                WHERE booking_id = :1
                """,
                (booking_id,),
            )
            self.connection.commit()
            self.create_notification(
                passenger_id,
                "Booking cancelled",
                f"Your booking #{booking_id} for ride {booking['ride_id']} has been cancelled.",
                'WARNING',
            )
            if booking.get('driver_id'):
                self.create_notification(
                    booking['driver_id'],
                    "Passenger cancelled booking",
                    f"A passenger cancelled booking #{booking_id} on your ride {booking['ride_id']}.",
                    'INFO',
                )
            return True, "Booking cancelled successfully."
        except oracledb.Error as exc:
            self.connection.rollback()
            print(f"Failed to cancel booking {booking_id}: {exc}")
            return False, "Failed to cancel booking. Please try again."

    def start_ride(self, ride_id: int) -> bool:
        """Mark a ride as in-progress and lock seats"""
        try:
            self.cursor.execute(
                """
                UPDATE rides
                SET status = 'IN_PROGRESS'
                WHERE ride_id = :1 AND status = 'ACTIVE'
                """,
                (ride_id,),
            )
            if self.cursor.rowcount == 0:
                self.connection.rollback()
                return False

            self.cursor.execute(
                """
                UPDATE bookings
                SET status = 'IN_PROGRESS'
                WHERE ride_id = :1 AND status = 'CONFIRMED'
                """,
                (ride_id,),
            )
            self.connection.commit()
            return True
        except oracledb.Error as exc:
            self.connection.rollback()
            print(f"Failed to start ride {ride_id}: {exc}")
            return False

    def all_payments_completed_for_ride(self, ride_id: int) -> bool:
        """Check if all payments are completed for a ride"""
        query = """
            SELECT COUNT(*) as pending_count
            FROM bookings b
            WHERE b.ride_id = :1 
              AND b.status IN ('CONFIRMED', 'IN_PROGRESS')
              AND b.payment_status != 'PAID'
        """
        result = self.execute_query(query, (ride_id,))
        if result and result[0][0] > 0:
            return False
        return True

    def complete_ride(self, ride_id: int) -> bool:
        """Mark a ride and its bookings as completed - only if all payments are completed"""
        # Check if all payments are completed
        if not self.all_payments_completed_for_ride(ride_id):
            return False
            
        try:
            self.cursor.execute(
                """
                UPDATE rides
                SET status = 'COMPLETED'
                WHERE ride_id = :1 AND status = 'IN_PROGRESS'
                """,
                (ride_id,),
            )
            if self.cursor.rowcount == 0:
                self.connection.rollback()
                return False

            self.cursor.execute(
                """
                UPDATE bookings
                SET status = 'COMPLETED'
                WHERE ride_id = :1 AND status = 'IN_PROGRESS'
                """,
                (ride_id,),
            )
            self.connection.commit()
            return True
        except oracledb.Error as exc:
            self.connection.rollback()
            print(f"Failed to complete ride {ride_id}: {exc}")
            return False

    def booking_exists(self, ride_id: int, passenger_id: int) -> bool:
        """Check if a passenger has a confirmed booking on a ride"""
        query = """
            SELECT 1 FROM bookings
            WHERE ride_id = :1 
              AND passenger_id = :2 
              AND status IN ('CONFIRMED', 'IN_PROGRESS', 'COMPLETED')
        """
        result = self.execute_query(query, (ride_id, passenger_id))
        return bool(result)

    def refresh_ride_statuses(self):
        """Auto-close rides/bookings whose departure time has passed"""
        update_rides = """
            UPDATE rides
            SET status = 'COMPLETED'
            WHERE status IN ('ACTIVE', 'IN_PROGRESS')
              AND departure_time < SYSTIMESTAMP
        """
        update_bookings = """
            UPDATE bookings
            SET status = 'COMPLETED'
            WHERE status IN ('CONFIRMED', 'IN_PROGRESS')
              AND ride_id IN (SELECT ride_id FROM rides WHERE departure_time < SYSTIMESTAMP)
        """
        self.execute_update(update_rides)
        self.execute_update(update_bookings)
    
    # Rating Operations
    def can_rate(self, ride_id: int, rater_id: int, rated_id: int) -> Tuple[bool, str]:
        """Check if a user can rate another user for a completed ride"""
        # Check if ride is completed
        ride = self.get_ride_by_id(ride_id)
        if not ride:
            return False, "Ride not found"
        
        if ride['status'] != 'COMPLETED':
            return False, "Ride must be completed before rating"
        
        # Check if payment is completed for passenger rating driver
        if rated_id == ride['driver_id']:
            # Passenger rating driver - check if payment is completed
            booking = self.get_booking_by_ride_and_passenger(ride_id, rater_id)
            if not booking:
                return False, "You must have a booking on this ride"
            if booking.get('payment_status') != 'PAID':
                return False, "Payment must be completed before rating"
        else:
            # Driver rating passenger - check if passenger has paid
            booking = self.get_booking_by_ride_and_passenger(ride_id, rated_id)
            if not booking:
                return False, "Passenger not found on this ride"
            if booking.get('payment_status') != 'PAID':
                return False, "Passenger payment must be completed"
        
        # Check if rating already exists
        existing = self.execute_query(
            "SELECT 1 FROM ratings WHERE ride_id = :1 AND rater_id = :2 AND rated_id = :3",
            (ride_id, rater_id, rated_id)
        )
        if existing:
            return False, "You have already rated this user for this ride"
        
        return True, "OK"

    def get_booking_by_ride_and_passenger(self, ride_id: int, passenger_id: int) -> Optional[Dict]:
        """Get booking by ride and passenger"""
        query = """
            SELECT booking_id, ride_id, passenger_id, status, seats_booked, payment_status
            FROM bookings
            WHERE ride_id = :1 AND passenger_id = :2
        """
        result = self.execute_query(query, (ride_id, passenger_id))
        if result:
            row = result[0]
            return {
                'booking_id': row[0],
                'ride_id': row[1],
                'passenger_id': row[2],
                'status': row[3],
                'seats_booked': row[4],
                'payment_status': row[5] if len(row) > 5 else 'PENDING'
            }
        return None

    def add_rating(
        self,
        ride_id: int,
        rater_id: int,
        rated_id: int,
        rating: float,
        comment: str = None,
    ) -> Tuple[bool, str]:
        """Add a rating for a ride.

        Returns (success: bool, error_message: str)
        """
        # Validate rating can be added
        can_rate, message = self.can_rate(ride_id, rater_id, rated_id)
        if not can_rate:
            return False, message
            
        # Handle NULL comment properly  
        comment_value = comment if comment and comment.strip() else None
        
        if not self._connected:
            if not self.connect():
                return False, "Database connection failed"
        
        try:
            # First check if table exists
            table_check = self.execute_query(
                "SELECT COUNT(*) FROM user_tables WHERE table_name = 'RATINGS'"
            )
            if not table_check or table_check[0][0] == 0:
                return False, "RATINGS table does not exist. Please run database_schema.sql to create it."
            
            # Oracle stores unquoted identifiers in uppercase
            # Since 'comment' is a reserved word, we must quote it as "COMMENT"
            # Always include comment column (even if NULL) - Oracle handles NULL values fine
            query = """
                INSERT INTO ratings (
                    ride_id,
                    rater_id,
                    rated_id,
                    rating,
                    "COMMENT"
                )
                VALUES (
                    :1,
                    :2,
                    :3,
                    :4,
                    :5
                )
            """
            params = (ride_id, rater_id, rated_id, rating, comment_value)
            
            self.cursor.execute(query, params)
            self.connection.commit()
            self.create_notification(
                rated_id,
                "New rating received",
                f"You received a {rating:.1f}★ rating from a recent ride.",
                'INFO',
            )
            return True, "Rating added successfully"
        except oracledb.Error as e:
            self.connection.rollback()
            error_msg = str(e)
            print(f"Error adding rating: {error_msg}")
            # Provide user-friendly error messages
            if "ORA-00001" in error_msg or "unique constraint" in error_msg.lower():
                return False, "You have already rated this user for this ride"
            elif "ORA-02291" in error_msg or "foreign key" in error_msg.lower():
                return False, "Invalid ride or user reference"
            elif "ORA-02290" in error_msg or "check constraint" in error_msg.lower():
                return False, "Rating value must be between 1 and 5"
            else:
                return False, f"Database error: {error_msg}"
        except Exception as e:
            error_msg = str(e)
            print(f"Unexpected error adding rating: {error_msg}")
            return False, f"Unexpected error: {error_msg}"
    
    def get_ratings_for_student(self, student_id: int) -> List[Dict]:
        """Get all ratings for a student"""
        query = """
            SELECT r.rating_id, r.ride_id, s.name as rater_name, r.rating,
                   r."COMMENT", r.rating_date
            FROM ratings r
            JOIN students s ON r.rater_id = s.student_id
            WHERE r.rated_id = :1
            ORDER BY r.rating_date DESC
        """
        result = self.execute_query(query, (student_id,))
        ratings = []
        for row in result:
            ratings.append({
                'rating_id': row[0],
                'ride_id': row[1],
                'rater_name': row[2],
                'rating': row[3],
                'comment': row[4],
                'rating_date': row[5]
            })
        return ratings
    
    def get_average_rating(self, student_id: int) -> float:
        """Get average rating for a student"""
        query = """
            SELECT AVG(rating) FROM ratings
            WHERE rated_id = :1
        """
        result = self.execute_query(query, (student_id,))
        if result and result[0][0]:
            return round(result[0][0], 2)
        return 0.0
    
    # Ride Matching
    def match_rides(self, source: str, destination: str, 
                   max_distance: float = 0.3) -> List[Dict]:
        """Match rides based on route similarity (simple string matching)"""
        # This is a simplified matching - in production, you'd use geocoding
        query = """
            SELECT r.ride_id, r.driver_id, s.name as driver_name, r.source_location, 
                   r.destination_location, r.departure_time, r.available_seats, 
                   r.price_per_seat, r.pickup_point, r.route_description,
                   (
                       SELECT NVL(SUM(b.seats_booked), 0)
                       FROM bookings b
                       WHERE b.ride_id = r.ride_id 
                         AND b.status IN ('CONFIRMED', 'IN_PROGRESS')
                   ) as booked_seats,
                   s.vehicle_details
            FROM rides r
            JOIN students s ON r.driver_id = s.student_id
            WHERE r.status = 'ACTIVE'
            AND (UPPER(r.source_location) LIKE UPPER(:1) 
                 OR UPPER(r.destination_location) LIKE UPPER(:2))
            ORDER BY r.departure_time
        """
        result = self.execute_query(query, (f'%{source}%', f'%{destination}%'))
        rides = []
        for row in result:
            rides.append({
                'ride_id': row[0],
                'driver_id': row[1],
                'driver_name': row[2],
                'source': row[3],
                'destination': row[4],
                'departure_time': row[5],
                'available_seats': row[6],
                'price_per_seat': row[7],
                'pickup_point': row[8],
                'route_description': row[9],
                'booked_seats': row[10] if len(row) > 10 and row[10] is not None else 0,
                'vehicle_details': row[11] if len(row) > 11 else None
            })
        return rides
    
    # Payment Operations
    def create_payment(self, booking_id: int, passenger_id: int, driver_id: int, 
                       amount: float, payment_method: str = 'WALLET') -> bool:
        """Create a payment record"""
        query = """
            INSERT INTO payments (booking_id, passenger_id, driver_id, amount, payment_method, payment_status)
            VALUES (:1, :2, :3, :4, :5, 'PENDING')
        """
        return self.execute_update(query, (booking_id, passenger_id, driver_id, amount, payment_method))
    
    def get_payment_by_booking(self, booking_id: int) -> Optional[Dict]:
        """Get payment for a booking"""
        query = """
            SELECT payment_id, booking_id, passenger_id, driver_id, amount, 
                   payment_method, payment_status, transaction_id, payment_date
            FROM payments
            WHERE booking_id = :1
            ORDER BY created_date DESC
        """
        result = self.execute_query(query, (booking_id,))
        if result:
            row = result[0]
            return {
                'payment_id': row[0],
                'booking_id': row[1],
                'passenger_id': row[2],
                'driver_id': row[3],
                'amount': row[4],
                'payment_method': row[5],
                'payment_status': row[6],
                'transaction_id': row[7],
                'payment_date': row[8]
            }
        return None
    
    def complete_payment(self, payment_id: int, transaction_id: str = None) -> bool:
        """Mark payment as completed and update booking payment status"""
        try:
            # Get payment details
            payment_query = "SELECT booking_id, passenger_id, driver_id, amount FROM payments WHERE payment_id = :1"
            payment_result = self.execute_query(payment_query, (payment_id,))
            if not payment_result:
                return False
            
            booking_id = payment_result[0][0]
            passenger_id = payment_result[0][1]
            driver_id = payment_result[0][2]
            amount = payment_result[0][3]
            
            # Update payment status
            self.cursor.execute(
                """
                UPDATE payments
                SET payment_status = 'COMPLETED',
                    payment_date = SYSTIMESTAMP,
                    transaction_id = :1
                WHERE payment_id = :2
                """,
                (transaction_id or f"TXN{payment_id}", payment_id)
            )
            
            # Update booking payment status
            self.cursor.execute(
                """
                UPDATE bookings
                SET payment_status = 'PAID'
                WHERE booking_id = :1
                """,
                (booking_id,)
            )
            
            # Create wallet transaction for driver (earning)
            self.create_wallet_transaction(
                driver_id, 'EARNING', amount, 
                f"Payment from passenger for booking {booking_id}",
                payment_id
            )
            
            # Update driver wallet balance
            self.update_wallet_balance(driver_id, amount)
            
            self.connection.commit()
            self.create_notification(
                passenger_id,
                "Payment completed",
                f"Payment for booking {booking_id} completed successfully.",
                'SUCCESS',
            )
            self.create_notification(
                driver_id,
                "Payment received",
                f"You received a payment of {amount:.2f} credits for booking {booking_id}.",
                'SUCCESS',
            )
            return True
        except oracledb.Error as exc:
            self.connection.rollback()
            print(f"Failed to complete payment {payment_id}: {exc}")
            return False
    
    def get_or_create_wallet(self, student_id: int) -> Dict:
        """Get or create wallet for a student"""
        query = """
            SELECT wallet_id, student_id, balance, created_date, last_updated
            FROM user_wallets
            WHERE student_id = :1
        """
        result = self.execute_query(query, (student_id,))
        if result:
            row = result[0]
            return {
                'wallet_id': row[0],
                'student_id': row[1],
                'balance': row[2],
                'created_date': row[3],
                'last_updated': row[4]
            }
        
        # Create wallet if doesn't exist
        query_insert = """
            INSERT INTO user_wallets (wallet_id, student_id, balance)
            VALUES ((SELECT NVL(MAX(wallet_id), 0) + 1 FROM user_wallets), :1, 0)
        """
        if self.execute_update(query_insert, (student_id,)):
            return self.get_or_create_wallet(student_id)
        return None
    
    def update_wallet_balance(self, student_id: int, amount: float) -> bool:
        """Update wallet balance"""
        try:
            wallet = self.get_or_create_wallet(student_id)
            if not wallet:
                return False
            
            new_balance = wallet['balance'] + amount
            if new_balance < 0:
                return False  # Insufficient funds
            
            self.cursor.execute(
                """
                UPDATE user_wallets
                SET balance = :1, last_updated = SYSTIMESTAMP
                WHERE student_id = :2
                """,
                (new_balance, student_id)
            )
            self.connection.commit()
            return True
        except oracledb.Error as exc:
            self.connection.rollback()
            print(f"Failed to update wallet balance: {exc}")
            return False
    
    def create_wallet_transaction(self, student_id: int, transaction_type: str, 
                                 amount: float, description: str = None, 
                                 related_payment_id: int = None) -> bool:
        """Create a wallet transaction"""
        wallet = self.get_or_create_wallet(student_id)
        if not wallet:
            return False
        
        query = """
            INSERT INTO wallet_transactions (
                transaction_id, wallet_id, student_id, transaction_type, 
                amount, description, related_payment_id
            )
            VALUES (
                (SELECT NVL(MAX(transaction_id), 0) + 1 FROM wallet_transactions),
                :1, :2, :3, :4, :5, :6
            )
        """
        return self.execute_update(
            query, (wallet['wallet_id'], student_id, transaction_type, amount, description, related_payment_id)
        )
    
    def get_payments_for_ride(self, ride_id: int) -> List[Dict]:
        """Get all payments for a ride"""
        query = """
            SELECT p.payment_id, p.booking_id, p.passenger_id, s.name as passenger_name,
                   p.amount, p.payment_method, p.payment_status, p.payment_date
            FROM payments p
            JOIN students s ON p.passenger_id = s.student_id
            JOIN bookings b ON p.booking_id = b.booking_id
            WHERE b.ride_id = :1
            ORDER BY p.created_date DESC
        """
        result = self.execute_query(query, (ride_id,))
        payments = []
        for row in result:
            payments.append({
                'payment_id': row[0],
                'booking_id': row[1],
                'passenger_id': row[2],
                'passenger_name': row[3],
                'amount': row[4],
                'payment_method': row[5],
                'payment_status': row[6],
                'payment_date': row[7]
            })
        return payments
    
    # Admin Operations - History Views
    def get_all_drivers(self) -> List[Dict]:
        """Get all registered drivers (students with vehicles)"""
        query = """
            SELECT s.student_id, s.name, s.email, s.department, s.semester,
                   s.vehicle_details, s.phone, s.registration_date,
                   s.approval_status, s.approval_date,
                   COUNT(DISTINCT r.ride_id) as total_rides,
                   COUNT(DISTINCT CASE WHEN r.status = 'COMPLETED' THEN r.ride_id END) as completed_rides,
                   NVL(SUM(CASE WHEN r.status = 'COMPLETED' THEN 
                       (r.price_per_seat * (
                           SELECT NVL(SUM(b.seats_booked), 0)
                           FROM bookings b
                           WHERE b.ride_id = r.ride_id AND b.status = 'COMPLETED'
                       ))
                   END), 0) as total_earnings,
                   (SELECT AVG(rt.rating) FROM ratings rt WHERE rt.rated_id = s.student_id) as avg_rating
            FROM students s
            LEFT JOIN rides r ON s.student_id = r.driver_id
            WHERE s.vehicle_available = 'Y' AND s.is_admin = 'N'
            GROUP BY s.student_id, s.name, s.email, s.department, s.semester,
                     s.vehicle_details, s.phone, s.registration_date,
                     s.approval_status, s.approval_date
            ORDER BY s.registration_date DESC
        """
        result = self.execute_query(query)
        drivers = []
        for row in result:
            drivers.append({
                'student_id': row[0],
                'name': row[1],
                'email': row[2],
                'department': row[3],
                'semester': row[4],
                'vehicle_details': row[5],
                'phone': row[6],
                'registration_date': row[7],
                'approval_status': row[8],
                'approval_date': row[9],
                'total_rides': row[10] or 0,
                'completed_rides': row[11] or 0,
                'total_earnings': float(row[12] or 0),
                'avg_rating': round(float(row[13] or 0), 2) if row[13] else 0.0
            })
        return drivers
    
    def get_all_passengers(self) -> List[Dict]:
        """Get all registered passengers (students without vehicles)"""
        query = """
            SELECT s.student_id, s.name, s.email, s.department, s.semester,
                   s.phone, s.registration_date,
                   s.approval_status, s.approval_date,
                   COUNT(DISTINCT b.booking_id) as total_bookings,
                   COUNT(DISTINCT CASE WHEN b.status = 'COMPLETED' THEN b.booking_id END) as completed_bookings,
                   NVL(SUM(CASE WHEN b.status = 'COMPLETED' THEN 
                       (b.seats_booked * r.price_per_seat)
                   END), 0) as total_spent,
                   (SELECT AVG(rt.rating) FROM ratings rt WHERE rt.rated_id = s.student_id) as avg_rating
            FROM students s
            LEFT JOIN bookings b ON s.student_id = b.passenger_id
            LEFT JOIN rides r ON b.ride_id = r.ride_id
            WHERE s.vehicle_available = 'N' AND s.is_admin = 'N'
            GROUP BY s.student_id, s.name, s.email, s.department, s.semester,
                     s.phone, s.registration_date,
                     s.approval_status, s.approval_date
            ORDER BY s.registration_date DESC
        """
        result = self.execute_query(query)
        passengers = []
        for row in result:
            passengers.append({
                'student_id': row[0],
                'name': row[1],
                'email': row[2],
                'department': row[3],
                'semester': row[4],
                'phone': row[5],
                'registration_date': row[6],
                'approval_status': row[7],
                'approval_date': row[8],
                'total_bookings': row[9] or 0,
                'completed_bookings': row[10] or 0,
                'total_spent': float(row[11] or 0),
                'avg_rating': round(float(row[12] or 0), 2) if row[12] else 0.0
            })
        return passengers
    
    def get_all_rides_history(self) -> List[Dict]:
        """Get complete ride history for admin"""
        query = """
            SELECT r.ride_id, r.driver_id, s.name as driver_name, s.email as driver_email,
                   r.source_location, r.destination_location, r.pickup_point,
                   r.departure_time, r.available_seats, r.price_per_seat,
                   r.status, r.route_description, r.created_date,
                   (SELECT COUNT(*) FROM bookings b WHERE b.ride_id = r.ride_id) as total_bookings,
                   (SELECT COUNT(*) FROM bookings b WHERE b.ride_id = r.ride_id AND b.status = 'COMPLETED') as completed_bookings,
                   (SELECT SUM(b.seats_booked * r.price_per_seat) 
                    FROM bookings b 
                    WHERE b.ride_id = r.ride_id AND b.payment_status = 'PAID') as total_revenue,
                   (SELECT AVG(rt.rating) FROM ratings rt WHERE rt.ride_id = r.ride_id) as avg_rating
            FROM rides r
            JOIN students s ON r.driver_id = s.student_id
            ORDER BY r.created_date DESC
        """
        result = self.execute_query(query)
        rides = []
        for row in result:
            rides.append({
                'ride_id': row[0],
                'driver_id': row[1],
                'driver_name': row[2],
                'driver_email': row[3],
                'source': row[4],
                'destination': row[5],
                'pickup_point': row[6],
                'departure_time': row[7],
                'available_seats': row[8],
                'price_per_seat': float(row[9] or 0),
                'status': row[10],
                'route_description': row[11],
                'created_date': row[12],
                'total_bookings': row[13] or 0,
                'completed_bookings': row[14] or 0,
                'total_revenue': float(row[15] or 0),
                'avg_rating': round(float(row[16] or 0), 2) if row[16] else 0.0
            })
        return rides
    
    # Reports
    def get_ride_statistics(self, student_id: int) -> Dict:
        """Get ride statistics for a student"""
        # As driver
        query_driver = """
            SELECT COUNT(*), SUM(
                price_per_seat *
                (
                    SELECT NVL(SUM(b.seats_booked), 0)
                    FROM bookings b
                    WHERE b.ride_id = r.ride_id 
                      AND b.status = 'COMPLETED'
                )
            )
            FROM rides r
            WHERE r.driver_id = :1 AND r.status = 'COMPLETED'
        """
        driver_stats = self.execute_query(query_driver, (student_id,))
        
        # As passenger
        query_passenger = """
            SELECT COUNT(*), SUM(b.seats_booked * r.price_per_seat)
            FROM bookings b
            JOIN rides r ON b.ride_id = r.ride_id
            WHERE b.passenger_id = :1 AND b.status = 'COMPLETED'
        """
        passenger_stats = self.execute_query(query_passenger, (student_id,))
        
        return {
            'rides_as_driver': driver_stats[0][0] if driver_stats and driver_stats[0][0] else 0,
            'earnings': driver_stats[0][1] if driver_stats and driver_stats[0][1] else 0,
            'rides_as_passenger': passenger_stats[0][0] if passenger_stats and passenger_stats[0][0] else 0,
            'spent': passenger_stats[0][1] if passenger_stats and passenger_stats[0][1] else 0
        }

