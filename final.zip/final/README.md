# 🚗 FastTrack - Student Carpool System

Welcome to FastTrack! This is a web-based carpool and ride-sharing platform built for university students. It helps students share rides, save money, and reduce traffic.

This guide is designed for **absolute beginners**. You don't need any programming experience to run this project! If you can copy and paste commands, you can run FastTrack.

---

## 🌟 What does this project do?
- **Drivers** (students with cars) can post rides they are taking to or from campus.
- **Passengers** (students needing a ride) can search for rides, book seats, and pay using a simulated digital wallet.
- Includes admin approvals, automatic ride completion, and a mutual rating system.

---

## 🛠️ Step 1: Install the Prerequisites (Only once!)

Before running the project, you need a tool called **Docker**. Docker packages the entire project (database + website) so you don't have to install Python or Oracle manually.

1. Download **Docker Desktop** from here: [https://www.docker.com/products/docker-desktop](https://www.docker.com/products/docker-desktop)
2. Install it on your Windows computer and open the application.
3. **Important:** Wait until Docker is fully running (you should see a green icon or "Docker is running" in the bottom-left corner of the Docker window).

---

## 📁 Step 2: Open your Terminal

You need to tell your computer where the project files are located.

1. Open **Command Prompt** (or PowerShell) on your computer. You can do this by searching for "cmd" in your Windows Start Menu.
2. Type the following command exactly and press **Enter** to navigate to the project folder:
   ```cmd
   cd "C:\Users\ESHOP\OneDrive\Desktop\DBMS project\final"
   ```

---

## 🚀 Step 3: Run the Project!

Now, you just need to run **one simple command** to start the entire system.

1. Copy and paste this command into your terminal and press **Enter**:
   ```cmd
   docker compose up -d --build
   ```
2. **Wait a few minutes.** Docker will download the database, install the web server, and start everything in the background. 
3. You will know it is done when you see messages saying `Started` next to the containers.

---

## 🌐 Step 4: Open the Website

1. Open your favorite web browser (Chrome, Edge, Firefox, etc.).
2. Go to this exact web address:
   ```text
   http://localhost:5000
   ```

🎉 **Congratulations! You are now looking at the FastTrack Carpool System.**

---

## 🔐 Login Credentials to Test the App

You can click "Register" to create a new student account, or you can use these pre-made accounts to test things immediately:

### Admin Account (Approves new users, views all data)
- **Email:** `admin@fasttrack.edu`
- **Password:** `admin123`

### Driver Account (Can post rides)
- **Email:** `john@university.edu`
- **Password:** `password123`

---

## 🛑 Step 5: How to Stop the Project

When you are done testing the project and want to shut it down to save your computer's memory, go back to your **Command Prompt**, make sure you are in the project folder, and run:

```cmd
docker compose down
```
This safely stops the database and the website. The next time you want to run it, just go to Step 2 and run `docker compose up -d`.

---

## ❓ Frequently Asked Questions (Troubleshooting)

**"It says port 5000 is already in use!"**
You probably already have the project running in the background! Just go to `http://localhost:5000` in your browser. If you want to restart it, run `docker compose down` first, then run `docker compose up -d`.

**"The website says 'Connection Refused'!"**
The Oracle database takes about 1-2 minutes to fully start up the very first time. Just wait 60 seconds and refresh the webpage!

**"It says 'docker compose is not recognized'!"**
This means Docker Desktop is not installed correctly, or it isn't running. Make sure you downloaded Docker Desktop and opened it before typing commands.

---
*Created for the Database Management Systems Course.*
