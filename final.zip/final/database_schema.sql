SET SERVEROUTPUT ON;

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE complaints CASCADE CONSTRAINTS PURGE';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE messages CASCADE CONSTRAINTS PURGE';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE notifications CASCADE CONSTRAINTS PURGE';
    
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE payments CASCADE CONSTRAINTS PURGE';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE vehicle_registrations CASCADE CONSTRAINTS PURGE';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE user_wallets CASCADE CONSTRAINTS PURGE';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE ratings CASCADE CONSTRAINTS PURGE';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP VIEW vw_driver_feedback';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP VIEW vw_driver_statistics';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE bookings CASCADE CONSTRAINTS PURGE';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE rides CASCADE CONSTRAINTS PURGE';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE students CASCADE CONSTRAINTS PURGE';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP PROCEDURE sp_add_rating';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE NOT IN (-4043, -04043) THEN RAISE; END IF;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP FUNCTION fn_get_driver_rating';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE NOT IN (-4043, -04043) THEN RAISE; END IF;
END;
/

BEGIN
    FOR rec IN (SELECT sequence_name FROM user_sequences
                WHERE sequence_name IN ('STUDENTS_SEQ', 'RIDES_SEQ', 'BOOKINGS_SEQ', 'RATINGS_SEQ', 
                                        'PAYMENTS_SEQ', 'NOTIFICATIONS_SEQ', 'MESSAGES_SEQ', 
                                        'VEHICLE_REG_SEQ', 'COMPLAINTS_SEQ', 'WALLET_TRANS_SEQ')) LOOP
        EXECUTE IMMEDIATE 'DROP SEQUENCE ' || rec.sequence_name;
    END LOOP;
END;
/

CREATE TABLE students (
    student_id NUMBER PRIMARY KEY,
    name VARCHAR2(100) NOT NULL,
    email VARCHAR2(100) UNIQUE NOT NULL,
    password VARCHAR2(100) NOT NULL,
    department VARCHAR2(50) NOT NULL,
    semester NUMBER NOT NULL,
    vehicle_available CHAR(1) DEFAULT 'N' CHECK (vehicle_available IN ('Y', 'N')),
    vehicle_details VARCHAR2(200),
    phone VARCHAR2(20),
    registration_date DATE DEFAULT SYSDATE,
    is_admin CHAR(1) DEFAULT 'N' CHECK (is_admin IN ('Y', 'N')),
    approval_status VARCHAR2(20) DEFAULT 'PENDING' CHECK (approval_status IN ('PENDING', 'APPROVED', 'REJECTED')),
    approval_date TIMESTAMP
);

CREATE TABLE rides (
    ride_id NUMBER PRIMARY KEY,
    driver_id NUMBER NOT NULL,
    source_location VARCHAR2(200) NOT NULL,
    destination_location VARCHAR2(200) NOT NULL,
    pickup_point VARCHAR2(200),
    departure_time TIMESTAMP NOT NULL,
    available_seats NUMBER NOT NULL CHECK (available_seats > 0),
    price_per_seat NUMBER(10,2) DEFAULT 0,
    status VARCHAR2(20) DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED')),
    route_description VARCHAR2(500),
    created_date TIMESTAMP DEFAULT SYSTIMESTAMP,
    CONSTRAINT fk_rides_driver FOREIGN KEY (driver_id) REFERENCES students(student_id) ON DELETE CASCADE
);

CREATE TABLE bookings (
    booking_id NUMBER PRIMARY KEY,
    ride_id NUMBER NOT NULL,
    passenger_id NUMBER NOT NULL,
    booking_time TIMESTAMP DEFAULT SYSTIMESTAMP,
    status VARCHAR2(20) DEFAULT 'CONFIRMED' CHECK (status IN ('CONFIRMED', 'IN_PROGRESS', 'CANCELLED', 'COMPLETED')),
    seats_booked NUMBER DEFAULT 1,
    payment_status VARCHAR2(20) DEFAULT 'PENDING' CHECK (payment_status IN ('PENDING', 'PAID', 'REFUNDED')),
    CONSTRAINT fk_bookings_ride FOREIGN KEY (ride_id) REFERENCES rides(ride_id) ON DELETE CASCADE,
    CONSTRAINT fk_bookings_passenger FOREIGN KEY (passenger_id) REFERENCES students(student_id) ON DELETE CASCADE
);

CREATE TABLE ratings (
    rating_id NUMBER PRIMARY KEY,
    ride_id NUMBER NOT NULL,
    rater_id NUMBER NOT NULL,
    rated_id NUMBER NOT NULL,
    rating NUMBER(2,1) NOT NULL CHECK (rating >= 1 AND rating <= 5),
    "COMMENT" VARCHAR2(500),
    rating_date TIMESTAMP DEFAULT SYSTIMESTAMP,
    CONSTRAINT fk_ratings_ride FOREIGN KEY (ride_id) REFERENCES rides(ride_id) ON DELETE CASCADE,
    CONSTRAINT fk_ratings_rater FOREIGN KEY (rater_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_ratings_rated FOREIGN KEY (rated_id) REFERENCES students(student_id) ON DELETE CASCADE
);

CREATE SEQUENCE students_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE rides_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE bookings_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE ratings_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE payments_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE notifications_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE messages_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE vehicle_reg_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE complaints_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE wallet_trans_seq START WITH 1 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER trg_students_pk
BEFORE INSERT ON students
FOR EACH ROW
BEGIN
    IF :NEW.student_id IS NULL THEN
        SELECT students_seq.NEXTVAL INTO :NEW.student_id FROM dual;
    END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_rides_pk
BEFORE INSERT ON rides
FOR EACH ROW
BEGIN
    IF :NEW.ride_id IS NULL THEN
        SELECT rides_seq.NEXTVAL INTO :NEW.ride_id FROM dual;
    END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_bookings_pk
BEFORE INSERT ON bookings
FOR EACH ROW
BEGIN
    IF :NEW.booking_id IS NULL THEN
        SELECT bookings_seq.NEXTVAL INTO :NEW.booking_id FROM dual;
    END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_ratings_pk
BEFORE INSERT ON ratings
FOR EACH ROW
BEGIN
    IF :NEW.rating_id IS NULL THEN
        SELECT ratings_seq.NEXTVAL INTO :NEW.rating_id FROM dual;
    END IF;
END;
/

-- Payments table
CREATE TABLE payments (
    payment_id NUMBER PRIMARY KEY,
    booking_id NUMBER NOT NULL,
    passenger_id NUMBER NOT NULL,
    driver_id NUMBER NOT NULL,
    amount NUMBER(10,2) NOT NULL,
    payment_method VARCHAR2(50) DEFAULT 'WALLET' CHECK (payment_method IN ('WALLET', 'CASH', 'CARD', 'ONLINE')),
    payment_status VARCHAR2(20) DEFAULT 'PENDING' CHECK (payment_status IN ('PENDING', 'COMPLETED', 'FAILED', 'REFUNDED')),
    transaction_id VARCHAR2(100),
    payment_date TIMESTAMP,
    created_date TIMESTAMP DEFAULT SYSTIMESTAMP,
    CONSTRAINT fk_payments_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    CONSTRAINT fk_payments_passenger FOREIGN KEY (passenger_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_payments_driver FOREIGN KEY (driver_id) REFERENCES students(student_id) ON DELETE CASCADE
);

-- User Wallets table
CREATE TABLE user_wallets (
    wallet_id NUMBER PRIMARY KEY,
    student_id NUMBER NOT NULL UNIQUE,
    balance NUMBER(10,2) DEFAULT 0 CHECK (balance >= 0),
    created_date TIMESTAMP DEFAULT SYSTIMESTAMP,
    last_updated TIMESTAMP DEFAULT SYSTIMESTAMP,
    CONSTRAINT fk_wallet_student FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

-- Wallet Transactions table
CREATE TABLE wallet_transactions (
    transaction_id NUMBER PRIMARY KEY,
    wallet_id NUMBER NOT NULL,
    student_id NUMBER NOT NULL,
    transaction_type VARCHAR2(20) NOT NULL CHECK (transaction_type IN ('DEPOSIT', 'WITHDRAWAL', 'PAYMENT', 'REFUND', 'EARNING')),
    amount NUMBER(10,2) NOT NULL,
    description VARCHAR2(500),
    related_payment_id NUMBER,
    transaction_date TIMESTAMP DEFAULT SYSTIMESTAMP,
    CONSTRAINT fk_wallet_trans_wallet FOREIGN KEY (wallet_id) REFERENCES user_wallets(wallet_id) ON DELETE CASCADE,
    CONSTRAINT fk_wallet_trans_student FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_wallet_trans_payment FOREIGN KEY (related_payment_id) REFERENCES payments(payment_id) ON DELETE SET NULL
);

-- Notifications table
CREATE TABLE notifications (
    notification_id NUMBER PRIMARY KEY,
    student_id NUMBER NOT NULL,
    title VARCHAR2(200) NOT NULL,
    message VARCHAR2(1000) NOT NULL,
    notification_type VARCHAR2(50) DEFAULT 'INFO' CHECK (notification_type IN ('INFO', 'SUCCESS', 'WARNING', 'ERROR', 'BOOKING', 'PAYMENT', 'RATING')),
    is_read CHAR(1) DEFAULT 'N' CHECK (is_read IN ('Y', 'N')),
    created_date TIMESTAMP DEFAULT SYSTIMESTAMP,
    CONSTRAINT fk_notifications_student FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

-- Messages table
CREATE TABLE messages (
    message_id NUMBER PRIMARY KEY,
    sender_id NUMBER NOT NULL,
    receiver_id NUMBER NOT NULL,
    ride_id NUMBER,
    subject VARCHAR2(200),
    message_text VARCHAR2(2000) NOT NULL,
    is_read CHAR(1) DEFAULT 'N' CHECK (is_read IN ('Y', 'N')),
    created_date TIMESTAMP DEFAULT SYSTIMESTAMP,
    CONSTRAINT fk_messages_sender FOREIGN KEY (sender_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_messages_receiver FOREIGN KEY (receiver_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_messages_ride FOREIGN KEY (ride_id) REFERENCES rides(ride_id) ON DELETE SET NULL
);

-- Vehicle Registrations table
CREATE TABLE vehicle_registrations (
    registration_id NUMBER PRIMARY KEY,
    student_id NUMBER NOT NULL,
    vehicle_type VARCHAR2(50) NOT NULL,
    vehicle_make VARCHAR2(100),
    vehicle_model VARCHAR2(100),
    vehicle_year NUMBER,
    license_plate VARCHAR2(50) UNIQUE,
    registration_number VARCHAR2(100),
    insurance_provider VARCHAR2(200),
    insurance_expiry DATE,
    registration_status VARCHAR2(20) DEFAULT 'PENDING' CHECK (registration_status IN ('PENDING', 'APPROVED', 'REJECTED', 'EXPIRED')),
    registration_date TIMESTAMP DEFAULT SYSTIMESTAMP,
    approval_date TIMESTAMP,
    CONSTRAINT fk_vehicle_reg_student FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

-- Complaints table
CREATE TABLE complaints (
    complaint_id NUMBER PRIMARY KEY,
    complainant_id NUMBER NOT NULL,
    respondent_id NUMBER,
    ride_id NUMBER,
    complaint_type VARCHAR2(50) DEFAULT 'GENERAL' CHECK (complaint_type IN ('GENERAL', 'SAFETY', 'PAYMENT', 'BEHAVIOR', 'VEHICLE', 'OTHER')),
    title VARCHAR2(200) NOT NULL,
    description VARCHAR2(2000) NOT NULL,
    status VARCHAR2(20) DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'UNDER_REVIEW', 'RESOLVED', 'DISMISSED')),
    admin_response VARCHAR2(2000),
    created_date TIMESTAMP DEFAULT SYSTIMESTAMP,
    resolved_date TIMESTAMP,
    CONSTRAINT fk_complaints_complainant FOREIGN KEY (complainant_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_complaints_respondent FOREIGN KEY (respondent_id) REFERENCES students(student_id) ON DELETE SET NULL,
    CONSTRAINT fk_complaints_ride FOREIGN KEY (ride_id) REFERENCES rides(ride_id) ON DELETE SET NULL
);

-- Triggers for new tables
CREATE OR REPLACE TRIGGER trg_payments_pk
BEFORE INSERT ON payments
FOR EACH ROW
BEGIN
    IF :NEW.payment_id IS NULL THEN
        SELECT payments_seq.NEXTVAL INTO :NEW.payment_id FROM dual;
    END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_notifications_pk
BEFORE INSERT ON notifications
FOR EACH ROW
BEGIN
    IF :NEW.notification_id IS NULL THEN
        SELECT notifications_seq.NEXTVAL INTO :NEW.notification_id FROM dual;
    END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_messages_pk
BEFORE INSERT ON messages
FOR EACH ROW
BEGIN
    IF :NEW.message_id IS NULL THEN
        SELECT messages_seq.NEXTVAL INTO :NEW.message_id FROM dual;
    END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_vehicle_reg_pk
BEFORE INSERT ON vehicle_registrations
FOR EACH ROW
BEGIN
    IF :NEW.registration_id IS NULL THEN
        SELECT vehicle_reg_seq.NEXTVAL INTO :NEW.registration_id FROM dual;
    END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_complaints_pk
BEFORE INSERT ON complaints
FOR EACH ROW
BEGIN
    IF :NEW.complaint_id IS NULL THEN
        SELECT complaints_seq.NEXTVAL INTO :NEW.complaint_id FROM dual;
    END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_wallet_trans_pk
BEFORE INSERT ON wallet_transactions
FOR EACH ROW
BEGIN
    IF :NEW.transaction_id IS NULL THEN
        SELECT wallet_trans_seq.NEXTVAL INTO :NEW.transaction_id FROM dual;
    END IF;
END;
/

-- Stored Functions
CREATE OR REPLACE FUNCTION fn_get_driver_rating (
    p_driver_id IN NUMBER
) RETURN NUMBER
IS
    v_avg_rating NUMBER := 0;
BEGIN
    SELECT NVL(AVG(rating), 0) INTO v_avg_rating
    FROM ratings
    WHERE rated_id = p_driver_id;
    RETURN ROUND(v_avg_rating, 2);
END;
/

-- Analytical Views
CREATE OR REPLACE VIEW vw_driver_feedback AS
SELECT
    dr.student_id AS driver_id,
    dr.name AS driver_name,
    pr.student_id AS passenger_id,
    pr.name AS passenger_name,
    rt.ride_id,
    rd.source_location,
    rd.destination_location,
    rt.rating,
    rt."COMMENT" AS comment_text,
    rt.rating_date
FROM ratings rt
JOIN students dr ON rt.rated_id = dr.student_id
JOIN students pr ON rt.rater_id = pr.student_id
JOIN rides rd ON rt.ride_id = rd.ride_id;

CREATE OR REPLACE VIEW vw_driver_statistics AS
SELECT
    s.student_id AS driver_id,
    s.name AS driver_name,
    COUNT(DISTINCT r.ride_id) AS rides_posted,
    NVL(SUM(b.seats_booked), 0) AS seats_booked,
    NVL(SUM(CASE WHEN pay.payment_status = 'COMPLETED' THEN pay.amount ELSE 0 END), 0) AS total_earnings,
    fn_get_driver_rating(s.student_id) AS avg_rating
FROM students s
LEFT JOIN rides r ON r.driver_id = s.student_id
LEFT JOIN bookings b ON b.ride_id = r.ride_id AND b.status IN ('CONFIRMED', 'COMPLETED')
LEFT JOIN payments pay ON pay.booking_id = b.booking_id
WHERE s.vehicle_available = 'Y'
GROUP BY s.student_id, s.name;

-- Stored Procedures
CREATE OR REPLACE PROCEDURE sp_add_rating (
    p_ride_id   IN NUMBER,
    p_rater_id  IN NUMBER,
    p_rated_id  IN NUMBER,
    p_rating    IN NUMBER,
    p_comment   IN VARCHAR2 DEFAULT NULL
) AS
    v_exists NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO v_exists
    FROM ratings
    WHERE ride_id = p_ride_id
      AND rater_id = p_rater_id
      AND rated_id = p_rated_id;

    IF v_exists > 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Rating already exists for this ride and user.');
    END IF;

    INSERT INTO ratings (ride_id, rater_id, rated_id, rating, "COMMENT", rating_date)
    VALUES (p_ride_id, p_rater_id, p_rated_id, p_rating, p_comment, SYSTIMESTAMP);
END;
/

-- Indexes
CREATE INDEX idx_rides_driver ON rides(driver_id);
CREATE INDEX idx_rides_status ON rides(status);
CREATE INDEX idx_rides_departure ON rides(departure_time);
CREATE INDEX idx_bookings_ride ON bookings(ride_id);
CREATE INDEX idx_bookings_passenger ON bookings(passenger_id);
CREATE INDEX idx_bookings_payment_status ON bookings(payment_status);
CREATE INDEX idx_students_email ON students(email);
CREATE INDEX idx_payments_booking ON payments(booking_id);
CREATE INDEX idx_payments_passenger ON payments(passenger_id);
CREATE INDEX idx_payments_status ON payments(payment_status);
CREATE INDEX idx_notifications_student ON notifications(student_id);
CREATE INDEX idx_notifications_read ON notifications(is_read);
CREATE INDEX idx_messages_sender ON messages(sender_id);
CREATE INDEX idx_messages_receiver ON messages(receiver_id);
CREATE INDEX idx_messages_read ON messages(is_read);
BEGIN
    EXECUTE IMMEDIATE 'DROP INDEX idx_wallet_trans_student';
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -1418 THEN RAISE; END IF;
END;
/
CREATE INDEX idx_wallet_trans_student ON wallet_transactions(student_id);
CREATE INDEX idx_complaints_complainant ON complaints(complainant_id);
CREATE INDEX idx_complaints_status ON complaints(status);

INSERT INTO students (name, email, password, department, semester, vehicle_available, vehicle_details, phone, is_admin, approval_status, approval_date)
VALUES ('FastTrack Admin', 'admin@fasttrack.edu', 'admin123', 'Administration', 0, 'N', NULL, NULL, 'Y', 'APPROVED', SYSTIMESTAMP);

INSERT INTO students (name, email, password, department, semester, vehicle_available, vehicle_details, phone, is_admin, approval_status, approval_date)
VALUES ('John Doe', 'john@university.edu', 'password123', 'Computer Science', 5, 'Y', 'Honda Civic 2020', '1234567890', 'N', 'APPROVED', SYSTIMESTAMP);

INSERT INTO students (name, email, password, department, semester, vehicle_available, vehicle_details, phone, is_admin, approval_status, approval_date)
VALUES ('Jane Smith', 'jane@university.edu', 'password123', 'Engineering', 3, 'N', NULL, '0987654321', 'N', 'PENDING', NULL);

COMMIT;

