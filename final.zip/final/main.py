import os
from datetime import datetime
from functools import wraps

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    session,
)

from database import Database


app = Flask(__name__)
app.secret_key = os.environ.get("FASTTRACK_SECRET_KEY", "fasttrack-dev-secret")
app.config["SESSION_PERMANENT"] = False

db = Database()


def get_db():
    if not db._connected:
        db.connect()
    return db

def db_with_refresh():
    database = get_db()
    database.refresh_ride_statuses()
    return database

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user" not in session:
            flash("Please log in to continue", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = session.get("user")
        if not user or user.get("is_admin") != "Y":
            flash("Admin access required.", "danger")
            return redirect(url_for("home"))
        return view(*args, **kwargs)

    return wrapped


@app.context_processor
def inject_user():
    return {"current_user": session.get("user")}


@app.route("/")
def home():
    if "user" not in session:
        return render_template("home_public.html")

    database = db_with_refresh()
    my_stats = database.get_ride_statistics(session["user"]["student_id"])
    upcoming_rides = database.get_my_rides(session["user"]["student_id"])[:5]
    bookings = database.get_my_bookings(session["user"]["student_id"])[:5]

    return render_template(
        "home_dashboard.html",
        stats=my_stats,
        upcoming_rides=upcoming_rides,
        bookings=bookings,
    )


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        form = request.form
        name = form.get("name")
        email = form.get("email")
        password = form.get("password")
        department = form.get("department")
        semester = form.get("semester")
        vehicle_available = form.get("vehicle_available", "N")
        phone = form.get("phone") or None

        if phone:
            phone = phone.strip()
            if len(phone) < 10 or len(phone) > 15:
                flash("Phone number must be between 10 and 15 digits", "danger")
                return redirect(url_for("register"))

        if not all([name, email, password, department, semester]):
            flash("Please fill all required fields", "danger")
            return redirect(url_for("register"))

        try:
            semester = int(semester)
            if semester < 1 or semester > 8:
                flash("Semester must be between 1 and 8", "danger")
                return redirect(url_for("register"))
        except ValueError:
            flash("Semester must be a number", "danger")
            return redirect(url_for("register"))

        # Consolidate vehicle details for students table
        vehicle_details = None
        if vehicle_available == "Y":
            vehicle_type = form.get("vehicle_type", "Car")
            vehicle_make = form.get("vehicle_make", "")
            vehicle_model = form.get("vehicle_model", "")
            vehicle_year = form.get("vehicle_year")
            license_plate = form.get("license_plate", "")
            registration_number = form.get("registration_number", "")
            vehicle_details = f"{vehicle_make} {vehicle_model} - {license_plate}".strip(' -')

        db_instance = get_db()
        if db_instance.register_student(
            name,
            email,
            password,
            department,
            semester,
            vehicle_available,
            vehicle_details,
            phone,
            is_admin="N",
            approval_status="PENDING",
        ):
            if vehicle_available == "Y":
                student = db_instance.get_student_by_email(email)
                if student:
                    try:
                        v_year = int(vehicle_year) if vehicle_year else None
                    except ValueError:
                        v_year = None
                    db_instance.register_vehicle(
                        student_id=student["student_id"],
                        vehicle_type=vehicle_type,
                        vehicle_make=vehicle_make,
                        vehicle_model=vehicle_model,
                        vehicle_year=v_year,
                        license_plate=license_plate,
                        registration_number=registration_number
                    )

            flash(
                "Registration submitted! You can log in after an admin approves your request.",
                "info",
            )
            return redirect(url_for("login"))

        flash("Registration failed. Email might already be registered.", "danger")

    return render_template("auth/register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        user = get_db().authenticate_student(email, password)
        if user:
            if user.get("approval_status") != "APPROVED":
                if user.get("approval_status") == "REJECTED":
                    flash(
                        "Your registration was rejected. Please contact the administrator.",
                        "danger",
                    )
                else:
                    flash("Your registration is pending admin approval.", "warning")
                return redirect(url_for("login"))
            session["user"] = user
            flash("Welcome back!", "success")
            return redirect(url_for("home"))

        flash("Invalid email or password", "danger")

    return render_template("auth/login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out successfully", "info")
    return redirect(url_for("home"))


@app.route("/rides/post", methods=["GET", "POST"])
@login_required
def post_ride():
    user = session["user"]
    if user.get("vehicle_available") != "Y":
        flash("You need to register a vehicle to post rides.", "warning")
        return redirect(url_for("home"))

    if request.method == "POST":
        form = request.form
        source = form.get("source")
        destination = form.get("destination")
        pickup_point = form.get("pickup_point")
        departure_date = form.get("departure_date")
        departure_time = form.get("departure_time")
        seats = form.get("available_seats")
        price = form.get("price_per_seat") or "0"
        description = form.get("route_description")

        if not all([source, destination, departure_date, departure_time, seats]):
            flash("Please fill all required fields", "danger")
            return redirect(url_for("post_ride"))

        try:
            departure_dt = datetime.strptime(
                f"{departure_date} {departure_time}", "%Y-%m-%d %H:%M"
            )
            if departure_dt < datetime.now():
                raise ValueError("Departure must be in the future")
            seats = int(seats)
            price = float(price)
        except ValueError as exc:
            flash(f"Invalid input: {exc}", "danger")
            return redirect(url_for("post_ride"))

        created = get_db().create_ride(
            driver_id=user["student_id"],
            source=source,
            destination=destination,
            departure_time=departure_dt,
            available_seats=seats,
            price_per_seat=price,
            pickup_point=pickup_point,
            route_description=description,
        )
        if created:
            flash("Ride posted successfully!", "success")
            return redirect(url_for("my_rides"))

        flash("Failed to post ride", "danger")

    return render_template("rides/post.html")


@app.route("/rides/search")
def search_rides():
    source = request.args.get("source")
    destination = request.args.get("destination")
    pickup_point = request.args.get("pickup_point")
    date = request.args.get("date")
    database = db_with_refresh()
    rides = database.search_rides(source, destination, pickup_point, date)
    return render_template(
        "rides/search.html",
        rides=rides,
        filters={
            "source": source or "",
            "destination": destination or "",
            "pickup_point": pickup_point or "",
            "date": date or "",
        },
    )


@app.route("/rides/match")
@login_required
def match_rides():
    source = request.args.get("source") or ""
    destination = request.args.get("destination") or ""
    matches = []
    if source or destination:
        matches = db_with_refresh().match_rides(source, destination)
    return render_template(
        "rides/match.html",
        matches=matches,
        filters={"source": source, "destination": destination},
    )


@app.route("/rides/<int:ride_id>/book", methods=["POST"])
@login_required
def book_ride(ride_id):
    database = db_with_refresh()
    ride = database.get_ride_by_id(ride_id)
    if not ride:
        flash("Ride not found.", "danger")
        return redirect(request.referrer or url_for("search_rides"))

    user_id = session["user"]["student_id"]
    if ride["driver_id"] == user_id:
        flash("You cannot book your own ride.", "warning")
        return redirect(request.referrer or url_for("search_rides"))

    if ride["status"] != "ACTIVE":
        flash("Ride is no longer active.", "warning")
        return redirect(request.referrer or url_for("search_rides"))

    seats = request.form.get("seats", "1")
    try:
        seats = int(seats)
    except ValueError:
        seats = 1
    if seats <= 0:
        seats = 1

    remaining = ride["available_seats"] - ride.get("booked_seats", 0)
    if remaining <= 0:
        flash("Ride is already full.", "danger")
        return redirect(request.referrer or url_for("search_rides"))
    if seats > remaining:
        flash(f"Only {remaining} seat(s) available.", "warning")
        return redirect(request.referrer or url_for("search_rides"))

    success = database.create_booking(ride_id, user_id, seats)
    if success:
        flash("Ride booked successfully!", "success")
    else:
        flash("Unable to book ride. Seats might be unavailable.", "danger")

    return redirect(request.referrer or url_for("search_rides"))


@app.route("/rides/my")
@login_required
def my_rides():
    rides = db_with_refresh().get_my_rides(session["user"]["student_id"])
    return render_template("rides/my.html", rides=rides)


@app.route("/rides/<int:ride_id>/start", methods=["POST"])
@login_required
def start_ride_action(ride_id):
    database = db_with_refresh()
    ride = database.get_ride_by_id(ride_id)
    if not ride or ride["driver_id"] != session["user"]["student_id"]:
        flash("You can only start rides that you posted.", "danger")
        return redirect(url_for("my_rides"))

    if ride["status"] != "ACTIVE":
        flash("Ride is no longer active.", "warning")
        return redirect(url_for("my_rides"))

    booked = ride.get("booked_seats", 0) or 0
    if booked < ride["available_seats"]:
        flash("Ride is not full yet. Seats must be filled before starting.", "info")
        return redirect(url_for("my_rides"))

    if database.start_ride(ride_id):
        flash("Ride started! Complete it once you reach your destination.", "success")
    else:
        flash("Unable to start ride. Please try again.", "danger")
    return redirect(url_for("my_rides"))


@app.route("/rides/<int:ride_id>/complete", methods=["POST"])
@login_required
def complete_ride_action(ride_id):
    database = db_with_refresh()
    ride = database.get_ride_by_id(ride_id)
    if not ride or ride["driver_id"] != session["user"]["student_id"]:
        flash("You can only complete rides that you posted.", "danger")
        return redirect(url_for("my_rides"))

    if ride["status"] != "IN_PROGRESS":
        flash("Ride must be in progress before it can be completed.", "warning")
        return redirect(url_for("my_rides"))

    # Check if all payments are completed
    if not database.all_payments_completed_for_ride(ride_id):
        flash("All passengers must complete payment before the ride can be completed.", "warning")
        return redirect(url_for("my_rides"))

    if database.complete_ride(ride_id):
        flash("Ride completed! You can now share ratings with your passengers.", "success")
    else:
        flash("Unable to complete ride. Please ensure all payments are completed.", "danger")
    return redirect(url_for("my_rides"))


@app.route("/bookings")
@login_required
def my_bookings():
    bookings = db_with_refresh().get_my_bookings(session["user"]["student_id"])
    return render_template("bookings.html", bookings=bookings)


@app.route("/bookings/<int:booking_id>/cancel", methods=["POST"])
@login_required
def cancel_booking_route(booking_id):
    success, message = db_with_refresh().cancel_booking(
        booking_id, session["user"]["student_id"]
    )
    flash(message, "success" if success else "danger")
    return redirect(request.referrer or url_for("my_bookings"))


@app.route("/admin/approvals")
@admin_required
def admin_approvals():
    pending = get_db().get_pending_students()
    return render_template("admin/approvals.html", pending=pending)


@app.route("/admin/approvals/<int:student_id>/<action>", methods=["POST"])
@admin_required
def admin_approval_action(student_id, action):
    status_map = {"approve": "APPROVED", "reject": "REJECTED"}
    status = status_map.get(action)
    if not status:
        flash("Invalid action.", "danger")
        return redirect(url_for("admin_approvals"))

    success = get_db().update_student_approval(student_id, status)
    if success:
        msg = "approved" if status == "APPROVED" else "rejected"
        flash(f"Student request {msg}.", "success")
    else:
        flash("Unable to update student approval.", "danger")
    return redirect(url_for("admin_approvals"))


@app.route("/admin/drivers")
@admin_required
def admin_drivers():
    """View all registered drivers"""
    drivers = db_with_refresh().get_all_drivers()
    return render_template("admin/drivers.html", drivers=drivers)


@app.route("/admin/passengers")
@admin_required
def admin_passengers():
    """View all registered passengers"""
    passengers = db_with_refresh().get_all_passengers()
    return render_template("admin/passengers.html", passengers=passengers)


@app.route("/admin/rides")
@admin_required
def admin_rides():
    """View complete ride history"""
    rides = db_with_refresh().get_all_rides_history()
    return render_template("admin/rides.html", rides=rides)


@app.route("/rides/<int:ride_id>/passengers")
@login_required
def ride_passengers(ride_id):
    ride = db_with_refresh().get_ride_by_id(ride_id)
    if not ride or ride["driver_id"] != session["user"]["student_id"]:
        flash("You can only view passengers for your rides.", "danger")
        return redirect(url_for("my_rides"))

    passengers = get_db().get_passengers_for_ride(ride_id)
    return render_template("rides/passengers.html", ride=ride, passengers=passengers)


@app.route("/ratings/add/<int:ride_id>/<int:rated_id>", methods=["GET", "POST"])
@login_required
def add_rating(ride_id, rated_id):
    database = db_with_refresh()
    ride = database.get_ride_by_id(ride_id)
    if not ride:
        flash("Ride not found", "danger")
        return redirect(url_for("home"))

    current_user_id = session["user"]["student_id"]
    
    # Validate rating can be added (checks completion, payment, etc.)
    can_rate, message = database.can_rate(ride_id, current_user_id, rated_id)
    if not can_rate:
        flash(message, "warning")
        if rated_id == ride["driver_id"]:
            return redirect(url_for("my_bookings"))
        else:
            return redirect(url_for("ride_passengers", ride_id=ride_id))

    if rated_id == ride["driver_id"]:
        # Passenger rating driver
        if not database.booking_exists(ride_id, current_user_id):
            flash("You can only rate drivers for rides you joined.", "danger")
            return redirect(url_for("my_bookings"))
    else:
        # Driver rating passenger
        if current_user_id != ride["driver_id"]:
            flash("Only the driver can rate passengers on this ride.", "danger")
            return redirect(url_for("home"))
        if not database.booking_exists(ride_id, rated_id):
            flash("That passenger is not confirmed on this ride.", "danger")
            return redirect(url_for("ride_passengers", ride_id=ride_id))

    if request.method == "POST":
        rating = request.form.get("rating")
        comment = request.form.get("comment")
        try:
            rating_value = float(rating)
            if rating_value < 1 or rating_value > 5:
                raise ValueError
        except ValueError:
            flash("Rating must be between 1 and 5", "danger")
            return redirect(request.url)

        success, message = database.add_rating(
            ride_id=ride_id,
            rater_id=current_user_id,
            rated_id=rated_id,
            rating=rating_value,
            comment=comment,
        )
        if success:
            flash("Rating submitted!", "success")
            return redirect(url_for("home"))
        else:
            flash(f"Failed to submit rating: {message}", "danger")

    rated_user = database.get_student_by_id(rated_id)
    return render_template(
        "ratings/add.html",
        ride=ride,
        rated_user=rated_user,
    )


@app.route("/bookings/<int:booking_id>/pay", methods=["GET", "POST"])
@login_required
def pay_booking(booking_id):
    database = db_with_refresh()
    booking = database.get_booking_with_ride(booking_id)
    if not booking or booking["passenger_id"] != session["user"]["student_id"]:
        flash("Booking not found or access denied.", "danger")
        return redirect(url_for("my_bookings"))
    
    ride = database.get_ride_by_id(booking["ride_id"])
    if not ride:
        flash("Ride not found.", "danger")
        return redirect(url_for("my_bookings"))
    
    # Calculate total amount
    total_amount = booking.get("seats_booked", 1) * ride.get("price_per_seat", 0)
    
    # Check if payment already exists
    existing_payment = database.get_payment_by_booking(booking_id)
    
    if request.method == "POST":
        payment_method = request.form.get("payment_method", "WALLET")
        
        # Create payment record
        if not existing_payment:
            payment_created = database.create_payment(
                booking_id, 
                session["user"]["student_id"], 
                ride["driver_id"],
                total_amount,
                payment_method
            )
            if not payment_created:
                flash("Failed to create payment record.", "danger")
                return redirect(url_for("pay_booking", booking_id=booking_id))
            existing_payment = database.get_payment_by_booking(booking_id)
        
        # Process payment based on method
        if payment_method == "WALLET":
            wallet = database.get_or_create_wallet(session["user"]["student_id"])
            if wallet["balance"] < total_amount:
                flash("Insufficient wallet balance. Please add funds first.", "warning")
                return redirect(url_for("pay_booking", booking_id=booking_id))
            
            # Deduct from wallet
            if database.update_wallet_balance(session["user"]["student_id"], -total_amount):
                # Create wallet transaction
                database.create_wallet_transaction(
                    session["user"]["student_id"],
                    "PAYMENT",
                    -total_amount,
                    f"Payment for booking {booking_id}",
                    existing_payment["payment_id"]
                )
                # Complete payment
                if database.complete_payment(existing_payment["payment_id"]):
                    flash("Payment completed successfully!", "success")
                    return redirect(url_for("my_bookings"))
                else:
                    # Refund if payment completion fails
                    database.update_wallet_balance(session["user"]["student_id"], total_amount)
                    flash("Payment processing failed. Amount refunded.", "danger")
            else:
                flash("Failed to process payment from wallet.", "danger")
        else:
            # For other payment methods, mark as completed (in real app, integrate payment gateway)
            transaction_id = request.form.get("transaction_id", f"TXN{existing_payment['payment_id']}")
            if database.complete_payment(existing_payment["payment_id"], transaction_id):
                flash("Payment completed successfully!", "success")
                return redirect(url_for("my_bookings"))
            else:
                flash("Failed to process payment.", "danger")
    
    wallet = database.get_or_create_wallet(session["user"]["student_id"])
    return render_template(
        "bookings/pay.html",
        booking=booking,
        ride=ride,
        total_amount=total_amount,
        existing_payment=existing_payment,
        wallet=wallet
    )


@app.route("/wallet")
@login_required
def my_wallet():
    database = db_with_refresh()
    wallet = database.get_or_create_wallet(session["user"]["student_id"])
    
    # Get recent transactions
    query = """
        SELECT transaction_id, transaction_type, amount, description, transaction_date
        FROM wallet_transactions
        WHERE student_id = :1
        ORDER BY transaction_date DESC
        FETCH FIRST 20 ROWS ONLY
    """
    transactions = database.execute_query(query, (session["user"]["student_id"],))
    trans_list = []
    for row in transactions:
        trans_list.append({
            'transaction_id': row[0],
            'transaction_type': row[1],
            'amount': row[2],
            'description': row[3],
            'transaction_date': row[4]
        })
    
    return render_template("wallet.html", wallet=wallet, transactions=trans_list)


@app.route("/wallet/add", methods=["POST"])
@login_required
def add_wallet_funds():
    amount = request.form.get("amount")
    try:
        amount = float(amount)
        if amount <= 0:
            raise ValueError
    except ValueError:
        flash("Invalid amount.", "danger")
        return redirect(url_for("my_wallet"))
    
    database = db_with_refresh()
    if database.update_wallet_balance(session["user"]["student_id"], amount):
        database.create_wallet_transaction(
            session["user"]["student_id"],
            "DEPOSIT",
            amount,
            f"Wallet deposit"
        )
        flash(f"${amount:.2f} added to wallet successfully!", "success")
    else:
        flash("Failed to add funds to wallet.", "danger")
    
    return redirect(url_for("my_wallet"))


@app.route("/rides/<int:ride_id>/payments")
@login_required
def ride_payments(ride_id):
    database = db_with_refresh()
    ride = database.get_ride_by_id(ride_id)
    if not ride or ride["driver_id"] != session["user"]["student_id"]:
        flash("You can only view payments for your rides.", "danger")
        return redirect(url_for("my_rides"))
    
    payments = database.get_payments_for_ride(ride_id)
    return render_template("rides/payments.html", ride=ride, payments=payments)


@app.route("/reports")
@login_required
def reports():
    database = db_with_refresh()
    stats = database.get_ride_statistics(session["user"]["student_id"])
    avg_rating = database.get_average_rating(session["user"]["student_id"])
    ratings = database.get_ratings_for_student(session["user"]["student_id"])
    wallet = database.get_or_create_wallet(session["user"]["student_id"])
    return render_template(
        "reports.html", stats=stats, avg_rating=avg_rating, ratings=ratings, wallet=wallet
    )


@app.route("/notifications")
@login_required
def notifications_page():
    database = get_db()
    notifications = database.get_notifications(
        session["user"]["student_id"], include_read=True, limit=100
    )
    unread_count = sum(1 for note in notifications if note.get("is_read") == "N")
    return render_template(
        "notifications.html",
        notifications=notifications,
        unread_count=unread_count,
    )


@app.route("/notifications/<int:notification_id>/read", methods=["POST"])
@login_required
def mark_notification_read(notification_id):
    database = get_db()
    database.mark_notification_read(notification_id, session["user"]["student_id"])
    return redirect(request.referrer or url_for("notifications_page"))


@app.route("/notifications/read-all", methods=["POST"])
@login_required
def mark_all_notifications():
    database = get_db()
    database.mark_all_notifications_read(session["user"]["student_id"])
    flash("All notifications marked as read.", "success")
    return redirect(url_for("notifications_page"))


@app.route("/messages")
@login_required
def messages_page():
    database = get_db()
    user_id = session["user"]["student_id"]
    inbox = database.get_inbox_messages(user_id)
    sent = database.get_sent_messages(user_id)
    return render_template("messages/index.html", inbox=inbox, sent=sent)


@app.route("/messages/compose", methods=["GET", "POST"])
@login_required
def compose_message():
    database = get_db()
    user_id = session["user"]["student_id"]
    recipients = database.get_messaging_recipients(user_id)
    ride_options = {ride["ride_id"]: ride for ride in database.get_my_rides(user_id)}
    for booking in database.get_my_bookings(user_id):
        ride_options.setdefault(
            booking["ride_id"],
            {
                "ride_id": booking["ride_id"],
                "source": booking["source"],
                "destination": booking["destination"],
                "departure_time": booking["departure_time"],
            },
        )

    if request.method == "POST":
        receiver_id = request.form.get("receiver_id")
        subject = request.form.get("subject")
        message_text = request.form.get("message_text")
        ride_id = request.form.get("ride_id") or None

        if not receiver_id or not message_text:
            flash("Please select a recipient and enter a message.", "danger")
            return redirect(url_for("compose_message"))

        try:
            receiver_id = int(receiver_id)
        except ValueError:
            flash("Invalid recipient selected.", "danger")
            return redirect(url_for("compose_message"))

        ride_id_val = None
        if ride_id:
            try:
                ride_id_val = int(ride_id)
            except ValueError:
                ride_id_val = None

        success = database.send_message(
            sender_id=user_id,
            receiver_id=receiver_id,
            subject=subject,
            message_text=message_text,
            ride_id=ride_id_val,
        )
        if success:
            flash("Message sent successfully!", "success")
            return redirect(url_for("messages_page"))
        flash("Failed to send message. Please try again.", "danger")

    return render_template(
        "messages/compose.html",
        recipients=recipients,
        ride_options=ride_options.values(),
    )


@app.route("/messages/<int:message_id>/read", methods=["POST"])
@login_required
def mark_message_read_route(message_id):
    database = get_db()
    database.mark_message_read(message_id, session["user"]["student_id"])
    return redirect(request.referrer or url_for("messages_page"))


@app.route("/complaints", methods=["GET", "POST"])
@login_required
def complaints_page():
    database = get_db()
    user_id = session["user"]["student_id"]

    if request.method == "POST":
        complaint_type = request.form.get("complaint_type") or "GENERAL"
        title = request.form.get("title")
        description = request.form.get("description")
        respondent_id = request.form.get("respondent_id") or None
        ride_id = request.form.get("ride_id") or None

        if not title or not description:
            flash("Title and description are required to submit a complaint.", "danger")
            return redirect(url_for("complaints_page"))

        respondent_val = None
        ride_val = None
        try:
            if respondent_id:
                respondent_val = int(respondent_id)
            if ride_id:
                ride_val = int(ride_id)
        except ValueError:
            flash("Invalid respondent or ride selected.", "danger")
            return redirect(url_for("complaints_page"))

        success = database.file_complaint(
            complainant_id=user_id,
            title=title,
            description=description,
            complaint_type=complaint_type,
            respondent_id=respondent_val,
            ride_id=ride_val,
        )
        if success:
            flash("Complaint submitted successfully.", "success")
            return redirect(url_for("complaints_page"))
        flash("Failed to submit complaint. Please try again.", "danger")

    ride_lookup = {ride["ride_id"]: ride for ride in database.get_my_rides(user_id)}
    for booking in database.get_my_bookings(user_id):
        ride_lookup.setdefault(
            booking["ride_id"],
            {
                "ride_id": booking["ride_id"],
                "source": booking["source"],
                "destination": booking["destination"],
                "departure_time": booking["departure_time"],
            },
        )

    complaints = database.get_complaints_for_user(user_id)
    recipients = database.get_messaging_recipients(user_id)

    return render_template(
        "complaints.html",
        complaints=complaints,
        ride_options=ride_lookup.values(),
        recipients=recipients,
    )


@app.route("/admin/complaints")
@admin_required
def admin_complaints():
    complaints = get_db().get_all_complaints()
    status_options = ["PENDING", "UNDER_REVIEW", "RESOLVED", "DISMISSED"]
    return render_template(
        "admin/complaints.html",
        complaints=complaints,
        status_options=status_options,
    )


@app.route("/admin/complaints/<int:complaint_id>/update", methods=["POST"])
@admin_required
def admin_update_complaint(complaint_id):
    status = request.form.get("status")
    response = request.form.get("admin_response")
    if not status:
        flash("Status is required.", "danger")
        return redirect(url_for("admin_complaints"))

    success = get_db().update_complaint_status(
        complaint_id,
        status,
        response,
        session["user"]["student_id"],
    )
    if success:
        flash(f"Complaint #{complaint_id} updated.", "success")
    else:
        flash("Unable to update complaint.", "danger")
    return redirect(url_for("admin_complaints"))


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
